#!/usr/bin/env python
# -*- coding: utf8 -*-

import glob
import os


def list_fun(root_dir, db_name):
    path = root_dir + '/' + db_name
    write_path = root_dir + '/tvt_split/' + db_name
    path_list = []

    # Avoid paths
    avoid_paths = [
        "imslp/75",
        "imslp/82",
        "imslp/83",
        "hand_picked_Spotify/6",  # Concerto
        "hand_picked_Spotify/18",
        "hand_picked_Spotify/19",
        "hand_picked_Spotify/2",
        "hand_picked_Spotify/36",
        "hand_picked_Spotify/43",
        "hand_picked_Spotify/46",
        "hand_picked_Spotify/50",
        "hand_picked_Spotify/60",
        "hand_picked_Spotify/61"
    ]

    for file_name in os.listdir(path):
        if file_name != '.DS_Store':
            this_path = db_name + '/' + file_name
            if this_path not in avoid_paths:
                path_list.append(this_path)

    # Brutal 8-1-1 split :)
    train_file = write_path + '_train.txt'
    open(train_file, 'w').close()
    valid_file = write_path + '_valid.txt'
    open(valid_file, 'w').close()
    test_file = write_path + '_test.txt'
    open(test_file, 'w').close()

    def aux_fun(f, e):
        with open(f, 'ab') as ff:
            ff.write(e + '\n')
        return

    for counter, e in enumerate(path_list):
        if (counter % 10) < 8:
            aux_fun(train_file, e)
        elif (counter % 10) == 8:
            aux_fun(valid_file, e)
        elif (counter % 10) == 9:
            aux_fun(test_file, e)
    return


def list_solo_fun(root_dir, db_name):
    path = root_dir + '/' + db_name
    path_list = []

    for folder_name in os.listdir(path):
        if folder_name != '.DS_Store':
            midi_file_name = glob.glob(path + '/' + folder_name + '/*_solo.mid')
            if len(midi_file_name) != 1:
                import pdb; pdb.set_trace()
            path_list.append(midi_file_name[0])

    # Brutal 8-1-1 split :)
    train_file = root_dir + '/Solo_index/' + db_name + '_train.txt'
    open(train_file, 'wb').close()
    valid_file = root_dir + '/Solo_index/' + db_name + '_valid.txt'
    open(valid_file, 'wb').close()
    test_file = root_dir + '/Solo_index/' + db_name + '_test.txt'
    open(test_file, 'wb').close()

    def aux_fun(f, e):
        with open(f, 'ab') as ff:
            ff.write(e + '\n')
        return

    for counter, e in enumerate(path_list):
        if (counter % 10) < 8:
            aux_fun(train_file, e)
        elif (counter % 10) == 8:
            aux_fun(valid_file, e)
        elif (counter % 10) == 9:
            aux_fun(test_file, e)
    return


if __name__ == '__main__':
    root_dir = '/Users/leo/Recherche/GitHub_Aciditeam/database/Orchestration/LOP_database_06_09_17'
    list_fun(root_dir, 'bouliane')
    list_fun(root_dir, 'imslp')
    list_fun(root_dir, 'hand_picked_Spotify')
    list_fun(root_dir, 'liszt_classical_archives')
