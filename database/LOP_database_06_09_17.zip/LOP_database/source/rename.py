#!/usr/bin/env python
# -*- coding: utf8 -*-

import glob
import re

from acidano.data_processing.utils.csv_to_dict import csv_to_dict
from acidano.data_processing.utils.dict_to_csv import dict_to_csv

simplify_mapping = {
    "Piccolo": "Violin",
    "Flute": "Violin",
    "Alto-Flute": "Violin",
    "Soprano-Flute": "Violin",
    "Bass-Flute": "Viola",
    "Contrabass-Flute": "Violoncello",
    "Pan Flute": "Remove",
    "Recorder": "Violin",
    "Ocarina": "Remove",
    "Oboe": "Violin",
    "Oboe-dAmore": "Violin",
    "Oboe de Caccia": "Remove",
    "English-Horn": "Viola",
    "Heckelphone": "Remove",
    "Piccolo-Clarinet-Ab": "Violin",
    "Clarinet": "Violin",
    "Clarinet-Eb": "Violin",
    "Clarinet-Bb": "Violin",
    "Piccolo-Clarinet-D": "Violin",
    "Clarinet-C": "Violin",
    "Clarinet-A": "Violin",
    "Basset-Horn-F": "Contrabass",
    "Alto-Clarinet-Eb": "Violoncello",
    "Bass-Clarinet-Bb": "Contrabass",
    "Bass-Clarinet-A": "Contrabass",
    "Contra-Alto-Clarinet-Eb": "Contrabass",
    "Contrabass-Clarinet-Bb": "Contrabass",
    "Bassoon": "Contrabass",
    "Contrabassoon": "Contrabass",
    "Soprano-Sax": "Sax",
    "Alto-Sax": "Sax",
    "Tenor-Sax": "Sax",
    "Baritone-Sax": "Sax",
    "Bass-Sax": "Sax",
    "Contrabass-Sax": "Sax",
    "Horn": "Horn",
    "Harmonica": "Remove",
    "Piccolo-Trumpet-Bb": "Trumpet",
    "Piccolo-Trumpet-A": "Trumpet",
    "High-Trumpet-F": "Trumpet",
    "High-Trumpet-Eb": "Trumpet",
    "High-Trumpet-D": "Trumpet",
    "Cornet": "Trumpet",
    "Trumpet": "Trumpet",
    "Trumpet-C": "Trumpet",
    "Trumpet-Bb": "Trumpet",
    "Cornet-Bb": "Trumpet",
    "Alto-Trumpet-F": "Trumpet",
    "Bass-Trumpet-Eb": "Trumpet",
    "Bass-Trumpet-C": "Trumpet",
    "Bass-Trumpet-Bb": "Trumpet",
    "Clarion": "Trumpet",
    "Trombone": "Trombone",
    "Alto-Trombone": "Trombone",
    "Soprano-Trombone": "Trombone",
    "Tenor-Trombone": "Trombone",
    "Bass-Trombone": "Trombone",
    "Contrabass-Trombone": "Trombone",
    "Euphonium": "Remove",
    "Tuba": "Tuba",
    "Bass-Tuba": "Tuba",
    "Contrabass-Tuba": "Tuba",
    "Flugelhorn": "Remove",
    "Piano": "Piano",
    "Celesta": "Remove",
    "Organ": "Organ",
    "Harpsichord": "Harpsichord",
    "Accordion": "Accordion",
    "Bandoneone": "Remove",
    "Harp": "Harp",
    "Guitar": "Guitar",
    "Bandurria": "Guitar",
    "Mandolin": "Guitar",
    "Lute": "Remove",
    "Lyre": "Remove",
    "Strings": "Remove",
    "Violin": "Violin",
    "Violins": "Violin",
    "Viola": "Viola",
    "Violas": "Viola",
    "Viola de gamba": "Viola",
    "Viola de braccio": "Remove",
    "Violoncello": "Violoncello",
    "Violoncellos": "Violoncello",
    "Contrabass": "Contrabass",
    "Basso continuo": "Remove",
    "Bass drum": "Remove",
    "Glockenspiel": "Remove",
    "Xylophone": "Remove",
    "Vibraphone": "Remove",
    "Marimba": "Remove",
    "Maracas": "Remove",
    "Bass-Marimba": "Remove",
    "Tubular-Bells": "Remove",
    "Clave": "Remove",
    "Bombo": "Remove",
    "Hi-hat": "Remove",
    "Triangle": "Remove",
    "Ratchet": "Remove",
    "Drum": "Remove",
    "Snare drum": "Remove",
    "Steel drum": "Remove",
    "Tambourine": "Remove",
    "Tam tam": "Remove",
    "Timpani": "Remove",
    "Cymbal": "Remove",
    "Castanets": "Remove",
    "Percussion": "Remove",
    "Voice": "Voice",
    "Voice soprano": "Voice",
    "Voice mezzo": "Voice",
    "Voice alto": "Voice",
    "Voice contratenor": "Voice",
    "Voice tenor": "Voice",
    "Voice baritone": "Voice",
    "Voice bass": "Voice",
    "Ondes martenot": "Remove",
    "Unknown": "Remove",
}
legit_name = simplify_mapping.keys()

path_csvs = glob.glob('../imslp/*/*.csv')


def legit(v):
    v_split = re.split(' and ', v)
    for v_part in v_split:
        if v_part not in legit_name:
            return False
    return True

for path_csv in path_csvs:
    print("**************************")
    print(path_csv)
    # Read the file
    dict_instru = csv_to_dict(path_csv)
    new_dict_instru = {}

    for k, v in dict_instru.iteritems():
        v_old = v
        while(not legit(v)):
            v = raw_input('New instru name for (' + k + ', ' +
                          v_old + '): ')
        new_dict_instru[k] = v

    dict_to_csv(new_dict_instru, path_csv)
